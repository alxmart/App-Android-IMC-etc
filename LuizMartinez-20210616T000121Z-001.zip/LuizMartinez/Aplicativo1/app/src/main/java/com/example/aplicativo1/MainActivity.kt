package com.example.aplicativo1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //   Criação de um campo val para relacionar-se com o componente "campo1"
        // da tela. O "campo1" é um componente do tipo "EditText".

        //   O método "findViewByID" irá procurar na nossa View (activity main)
        // pelo componente que tem o id "campo1".

        val campo1: EditText = findViewById(R.id.campo1)
        val campo2: EditText = findViewById(R.id.campo2)

        //  Botões
        //  O nome do objeto "botão1" não precisa ser o mesmo nome
        // do id "exercício1" que foi configurado na tela

        val botao1: Button = findViewById(R.id.exercicio1)
        val botao2: Button = findViewById(R.id.exercicio2)
        val botao3: Button = findViewById(R.id.exercicio3)
        val botao4: Button = findViewById(R.id.exercicio4)

        //    Configurar um evento que  irá ocorrer ao clicar/tocar sobre o "botão1"
        //    Para acessar os recursos que estão presentes na classe Button (a qual
        //  o nosso "botao1" pertence, utilizamos o ponto final após o nome do objeto
        botao1.setOnClickListener {
            //  recuperar e armazenar em uma variável (var) o valor do "campo1"
            var n1 = campo1.text
            var n2 = campo2.text
            var auxiliar = n1

            //  Trocar os valores
            n1 = n2
            n2 = auxiliar

            // Colocar/escrever os valores de "n1" e "n2" de "campo1" e "campo2"
            campo1.text = n1
            campo2.text = n2

        }

        //Botão 2 (Exercício 2)
        botao2.setOnClickListener {
            //  Recuperar o valor do "campo1" e converter para inteiro
            var n1 = campo1.text.toString().toInt()
            var n2 = campo2.text.toString().toInt()

            var quadradoN1 = n1 * n1 // Calcular o valor de "n1' ao quadrado
            var quadradoN2 = n2 * n2 // Calcular o valor de "n1' ao quadrado

            // Exibir no "campo1" e no "campo2" o valor do resultado de
            // "n1" e "n2" ao quadrado
            campo1.setText(quadradoN1.toString())
            campo2.setText(quadradoN2.toString())

            // Exibir o resultado da soma entre "quadradoN1" e "quadradoN2"
            // dentro de uma mensagem da classe Toast
            Toast.makeText(applicationContext,
                    (quadradoN1 + quadradoN2).toString(), Toast.LENGTH_LONG).show()

            // Para escrver mensagem no LogCat:
            // A "TAG_FILTRO" pode ser qualquer texto e tem a finalidade de
            // encontrarmos mais facilmente pelas nossas mensagens

            Log.d( "TAG_FILTRO", "Valor n1 ao quadrado: $quadradoN1")
            Log.d( "TAG_FILTRO", "Valor n2 ao quadrado: $quadradoN2")

            // Para fazer soma ou qualquer operação, é necessário finalizar o texto,
            // ou seja, fechar a aspas e depois juntar com o sinal  9com o sinal de +) o valor
            // da operação
            Log.d( "TAG_FILTRO", "Resultado soma:" + (quadradoN1 + quadradoN2))


        }

        //Botão 3 (Exercício 3)
        botao3.setOnClickListener {
            //  Ler os valores do campo e converter para números decimais
            var peso = campo1.text.toString().toDouble()
            var altura = campo2.text.toString().toDouble()

            // Calcular o IMC e armazenar o resultado em uma "var"
            var resultado = peso / Math.pow(altura, 2.0)

            // Exibir o resultado usando o Toast
            Toast.makeText(applicationContext,
                     "IMC: " + resultado, Toast.LENGTH_LONG).show()

        }

        //Botão 4 (Exercício 4)
        botao4.setOnClickListener {

            // Recuperar o vlor do campo1
            var numeroMes = campo1.text.toString().toInt()

            // É possível utilizar a estrutura "If/Else" mas podemos simplificar
            // com o comando "when" e usá-lo como uma expressão, ou seja seja, fazer
            // o comando "when" retiornar um valor

            var nomeMes = when(numeroMes) {
                1 -> "Janeiro";  2 -> "Fevereiro";  3 -> "Março";     4 -> "Abril"
                5 -> "Maio";     6 -> "Junho";      7 -> "Julho";     8 -> "Agosto"
                9 -> "Setembro"; 10 -> "Outubro";   11 -> "Novembro"; 12 -> "Dezembro"
                else -> "Valor de Mês inválido"

            }
            Toast.makeText(applicationContext, nomeMes, Toast.LENGTH_LONG).show()


        }

    }
}






















